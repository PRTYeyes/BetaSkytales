package skytales.skytales.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class PEGASUSSWORD extends Item {
    public PEGASUSSWORD(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {

        if (!world.isClientSide()) {
            System.out.println(player.getSpeed());
            player.sendMessage(Component.nullToEmpty("This Item Is Not currently complete"),player.getUUID());
        }

        return super.use(world, player, hand);
    }
}
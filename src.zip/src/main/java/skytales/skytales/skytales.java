package skytales.skytales;

import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import skytales.skytales.init.ItemInit;

// The value here should match an entry in the META-INF/mods.toml file
@Mod("skytales")
public class skytales {

    public static final String MOD_ID = "skytales";
    public static final String MOD_IDII = "skytalesii";
    public static final String MOD_IDIII = "skytalesiii";
    public static final String MOD_IDIV = "skytalesiv";
    public static final String MOD_IDV = "skytalesv";

    public static final CreativeModeTab SKYTALES_MISC = new CreativeModeTab(MOD_ID) {
        @Override
        @OnlyIn(Dist.CLIENT)
        public ItemStack makeIcon() {
            return new ItemStack(ItemInit.PEGASUS_FEATHER.get());
        }
    };

    public static final CreativeModeTab SKYTALES_WEAPONS = new CreativeModeTab(MOD_IDII) {
        @Override
        @OnlyIn(Dist.CLIENT)
        public ItemStack makeIcon() {
            return new ItemStack(ItemInit.PEGASUS_DAGGER.get());
        }
    };

    public static final CreativeModeTab SKYTALES_ACCESSORIES = new CreativeModeTab(MOD_IDIII) {
        @Override
        @OnlyIn(Dist.CLIENT)
        public ItemStack makeIcon() {
            return new ItemStack(ItemInit.HALO_OF_HELL.get());
        }
    };

    public skytales() {

        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();

        ItemInit.ITEMS.register(bus);

        MinecraftForge.EVENT_BUS.register(this);
    }
}

package skytales.skytales.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.crafting.conditions.TrueCondition;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import skytales.skytales.item.PEGASUSSWORD;
import skytales.skytales.skytales;

import java.util.function.Supplier;

public class ItemInit {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, skytales.MOD_ID);



//ITEMS (5)
    //MISC (2)
    public static final RegistryObject<Item> PEGASUS_FEATHER = register("pegasus_feather",
            () -> new Item(new Item.Properties().tab(skytales.SKYTALES_MISC)));

    public static final RegistryObject<Item> PEGASUS_WING = register("pegasus_wing",
            () -> new Item(new Item.Properties().tab(skytales.SKYTALES_MISC)));

    //SWORDS/WEAPONS (2)
    public static final RegistryObject<Item> PEGASUS_DAGGER = register("pegasus_dagger",
            () -> new PEGASUSSWORD(new Item.Properties().tab(skytales.SKYTALES_WEAPONS).stacksTo(1)));

    public static final RegistryObject<Item> WINGED_SWORD = register("winged_sword",
            () -> new Item(new Item.Properties().tab(skytales.SKYTALES_WEAPONS)));

    //ACCESSORIES (1)
    public static final RegistryObject<Item> HALO_OF_HELL = register("halo_of_hell",
            () -> new Item(new Item.Properties().tab(skytales.SKYTALES_ACCESSORIES)));

    //ARMOR


    //TOOLS
//end

    private static <T extends Item> RegistryObject<T> register(final String name, final Supplier<T> item) {
        return ITEMS.register(name, item);
    }
}
